/*
 * 
 */
package trackit.diagram.part;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.tooling.runtime.update.UpdaterNodeDescriptor;

/**
 * @generated
 */
public class TrackitNodeDescriptor extends UpdaterNodeDescriptor {
	/**
	 * @generated
	 */
	public TrackitNodeDescriptor(EObject modelElement, int visualID) {
		super(modelElement, visualID);
	}

}
