/*
 * 
 */
package trackit.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.AppearancePreferencePage;

import trackit.diagram.part.TrackitDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramAppearancePreferencePage extends AppearancePreferencePage {

	/**
	 * @generated
	 */
	public DiagramAppearancePreferencePage() {
		setPreferenceStore(TrackitDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
