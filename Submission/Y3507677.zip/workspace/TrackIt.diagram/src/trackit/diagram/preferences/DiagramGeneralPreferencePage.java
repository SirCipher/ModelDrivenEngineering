/*
 * 
 */
package trackit.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

import trackit.diagram.part.TrackitDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	 * @generated
	 */
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(TrackitDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
