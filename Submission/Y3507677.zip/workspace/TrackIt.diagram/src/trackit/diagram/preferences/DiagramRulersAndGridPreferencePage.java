/*
 * 
 */
package trackit.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

import trackit.diagram.part.TrackitDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	 * @generated
	 */
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(TrackitDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
