/*
 * 
 */
package trackit.diagram.providers;

import org.eclipse.gmf.runtime.common.ui.services.icon.IIconProvider;
import org.eclipse.gmf.tooling.runtime.providers.DefaultElementTypeIconProvider;

/**
 * @generated
 */
public class TrackitIconProvider extends DefaultElementTypeIconProvider
		implements IIconProvider {

	/**
	 * @generated
	 */
	public TrackitIconProvider() {
		super(TrackitElementTypes.TYPED_INSTANCE);
	}

}
