/*
 * 
 */
package trackit.diagram.edit.helpers;

/**
 * @generated
 */
public class MemberEditHelper extends TrackitBaseEditHelper {
}
