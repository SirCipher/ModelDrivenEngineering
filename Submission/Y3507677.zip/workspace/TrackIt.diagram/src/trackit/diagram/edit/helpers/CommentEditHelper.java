/*
 * 
 */
package trackit.diagram.edit.helpers;

/**
 * @generated
 */
public class CommentEditHelper extends TrackitBaseEditHelper {
}
