/*
 * 
 */
package trackit.diagram.edit.helpers;

/**
 * @generated
 */
public class IssueEditHelper extends TrackitBaseEditHelper {
}
