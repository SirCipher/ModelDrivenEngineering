/*
 * 
 */
package trackit.diagram.edit.helpers;

/**
 * @generated
 */
public class VersionEditHelper extends TrackitBaseEditHelper {
}
